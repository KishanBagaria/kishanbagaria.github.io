<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html>

<head>
	<title>Matt's String Reverser (DEMO VERSION)</title>
</head>

<body bgcolor=lightgray link=green vlink=green>

<!--
	DEMO VERSION!
	This is the demo version of Matt's String Reverser.
	You are not allowed to inspect the source code of
	this program, make any modifications to it, or
	distribute it under penalty of law.
	
	(c) 1999 Matt
-->

<!-- DEMO VERSION! --><h1>Matt's String <font color=red>Reverser</font> (DEMO VERSION)</h1>
<!-- DEMO VERSION! --><p>Welcome to the demo version <b>Matt's String Reverser</b>, a handy tool (written in PHP!) for your string reversing needs.</p>
<!-- DEMO VERSION! --><p>If you want to reverse longer strings, please use the <a href=https://www.glue.bar/mattsstringreverser>full version</a> available online!</p>
<!-- DEMO VERSION! --><hr />

<?php
/*** DEMO VERSION! **/if (isset($_POST["reverse_me"])) {
/*** DEMO VERSION! **/	echo "<p><b>Your reversed string is:</b></p>";
/*** DEMO VERSION! **/	$original = $_POST["reverse_me"];
/*** DEMO VERSION! **/	$length = strlen($original);
/*** DEMO VERSION! **/	$reversed = "";
/*** DEMO VERSION! **/	for ($position = 0; $position < $length && $position < 50; $position = $position + 1) {
/*** DEMO VERSION! **/		$reversed = $original[$position] . $reversed;
/*** DEMO VERSION! **/	}
/*** DEMO VERSION! **/	echo "<p>";
/*** DEMO VERSION! **/	echo $reversed;
/*** DEMO VERSION! **/	echo "</p>";
/*** DEMO VERSION! **/	echo "<p><small>Thank you for using Matt's String Reverser (DEMO VERSION)! Don't forget to tell your friends about this service.</small></p>";
/*** DEMO VERSION! **/	echo "<p><small>Here is a present for using the demo version: gpj.flesmih-ttam/resrevergnirtssttam/rab.eulg.www//:sptth - you will need to use the full version of Matt's String Reverser to collect the present ;)</small></p>";
/*** DEMO VERSION! **/	echo "<hr />";
/*** DEMO VERSION! **/}
?>

<!-- DEMO VERSION! --><form method=POST action=index.php>
<!-- DEMO VERSION! --><textarea name=reverse_me maxlength=50 rows=2 cols=25></textarea>
<!-- DEMO VERSION! --><input type=submit value=Reverse>
<!-- DEMO VERSION! --></form>

<!-- DEMO VERSION! --><p>Optimized for modern browsers!</p>
<!-- DEMO VERSION! --><p align=right><small>Matt</small></p>

</body>
</html>